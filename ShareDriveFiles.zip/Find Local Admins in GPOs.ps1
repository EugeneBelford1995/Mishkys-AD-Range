﻿$Computers = (Get-ADComputer -Filter * -SearchBase "ou=clients,dc=test,dc=local").Name
ForEach($Computer in $Computers)
{
Invoke-Command -ComputerName $Computer -ScriptBlock {Get-LocalGroupMember -Group "Administrators" | Export-Csv .\LocalAdmins.csv}
}

#'grep' SYSVOL & find the GPO that puts an AD group in a local group
$ErrorActionPreference = 'SilentlyContinue'
$LocalGroup = "S-1-5-32-555"
$DomainFQDN = (Get-ADDomain).DNSRoot
$GPOfiles = (Get-ChildItem \\$DomainFQDN\SYSVOL\$DomainFQDN\Policies\ -Recurse | Select-String "$LocalGroup" -List | Select Path).Path

ForEach($GPOfile in $GPOfiles)
{
$GPOGUID = ($GPOfile.Split("{")[1]).Split("}")[0]
$RawContent = Get-Content $GPOfile | Select-String -Pattern "$LocalGroup"

#Parse the data & getthe AD group's SID from the raw data
$Temp = (($RawContent -split("=") | ConvertFrom-String).P2).Replace('*','')
$string = ($Temp | Out-String) ; $GroupSID = $string -replace '\s',''

$ADGroup = (Get-ADGroup -Filter * -Properties * | Where-Object {$_.SID -like "*$GroupSID*"}).CN
Add-Content -Path C:\Users\Public\Documents\GPOs.txt "This is the AD group that's added to the specifid local group via GPO:"
$ADGroup | Out-File C:\Users\Public\Documents\GPOs.txt -Append
Add-Content -Path C:\Users\Public\Documents\GPOs.txt " "

#Find what OU the GPO is applied to
$OUAppliedTo = (Get-ADOrganizationalUnit -Filter * -Properties * | Where-Object {$_.gPLink -like “*$GPOGUID*”}).Name
Add-Content -Path C:\Users\Public\Documents\GPOs.txt "This is the OU that the GPO is applied to:"
$OUAppliedTo | Out-File C:\Users\Public\Documents\GPOs.txt -Append
Add-Content -Path C:\Users\Public\Documents\GPOs.txt " "

#Show the GPO that is applying this group
Add-Content -Path C:\Users\Public\Documents\GPOs.txt "This is the GPO's Display Name that is adding the group above to the specified local group:"
$root = (Get-ADDomain).DistinguishedName ; (Get-ADObject -Filter * -SearchBase “cn=policies,cn=system,$root” -Properties * | Where-Object {$_.Name -like "*$GPOGUID*"}).DisplayName | Out-File C:\Users\Public\Documents\GPOs.txt -Append
Add-Content -Path C:\Users\Public\Documents\GPOs.txt " " 
Add-Content -Path C:\Users\Public\Documents\GPOs.txt " --- Next GPO ---  "
Add-Content -Path C:\Users\Public\Documents\GPOs.txt "  "
}