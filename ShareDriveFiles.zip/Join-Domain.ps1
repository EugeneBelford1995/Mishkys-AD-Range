﻿Write-Host "Join the us.lab.local domain"
$User = Read-Host "Please enter your domain admin username" 
Add-Computer -DomainName test.local -Credential $User -restart -force