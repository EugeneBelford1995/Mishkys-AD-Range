﻿$Computers = (Get-ADComputer -Filter * -Properties *).CN
ForEach ($computer in $computers)
{
1..1024 | % {echo ((new-object Net.Sockets.TcpClient).Connect("$computer",$_)) "$computer Port $_ is open!"} 2>$null
}