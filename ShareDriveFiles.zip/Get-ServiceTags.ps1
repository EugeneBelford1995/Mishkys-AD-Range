﻿#https://exchangepedia.com/2007/02/getting-dell-service-tag-using-powershell.html
$Computers = (Get-ADComputer -Filter *).Name
ForEach($Computer in $Computers)
{
Get-CimInstance win32_SystemEnclosure -ComputerName $Computer | Select-Object PSComputerName, SerialNumber | Export-Csv .\SerialNumbers
}