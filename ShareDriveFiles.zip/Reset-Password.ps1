﻿# --- Option 5, Reset a given user's password ---
Function Reset-Password {
$target = Read-Host "Enter the SamAccountName of the user whose password you want to reset."
If(Get-ADUser -Filter {SamAccountName -eq $target})
{

Try
{
Set-ADAccountPassword -Identity $target -Reset -NewPassword (ConvertTo-SecureString -AsPlainText "Password00!!" -Force)
Write-Host "$target password is now Password00!! . Enjoy."

} #Close the try
Catch {Write-Host "Error, you probably don't have the rights required (GenericAll, ExtendedRight with GUID all 0s, etc). Please enumerate again. If you have WriteOwner or WriteDACL then use options 1 or 2 first."}
} #Close the If
Else {Write-Host "The target must be a user's SamAccountName"}
} #Close the function