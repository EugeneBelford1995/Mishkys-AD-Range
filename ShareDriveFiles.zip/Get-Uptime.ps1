﻿#https://www.tutorialspoint.com/how-to-get-the-system-uptime-with-powershell
$ErrorActionPreference = "SilentlyContinue"
$ADRoot = (Get-ADDomain).DistinguishedName
$Workstations = (Get-ADComputer -Filter * -SearchBase "ou=clients,$ADRoot").Name
$CurrentDate = (Get-Date)

ForEach ($Workstation in $Workstations)
{
$LastBoot = (Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $Workstation).LastBootUpTime
If (($LastBoot -lt (Get-Date).AddHours(-8)) -and ($LastBoot -ne $null))
{
Write-Host "$Workstation has been up since $LastBoot !"
}
}